import { criarPastaDinamica } from "./modulo_fs/lib/fs_mkdir.cjs";

//Criar Pasta("./relatorios")
//criarPasta("./documentos");
criarPastaDinamica("./relatorios2")
criarPastaDinamica("./relatorios3")
criarPastaDinamica("./relatorios4")
criarPastaDinamica("./relatorios5")