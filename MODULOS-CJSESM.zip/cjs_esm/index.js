import { acelerar } from "./lib/veiculo";

import { fs } from "./lib/Modulo.cjs";
console.log(acelerar());
console.log(acelerar());
console.log(fs);
