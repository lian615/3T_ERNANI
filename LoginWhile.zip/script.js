// CRIE UM PROGRAMA QUE CHEQUE USUÁRIO E SENHA 
// CASO O USUÁRIO E SENHA SEJAM IGUAIS AO CADASTRADO, EXIBA UMA MENSAGEM DE SUCESSO
// CASO CONTRÁRIO, PERGUNTE NOVAMENTE (WHILE)
const usuario = "Admin"
const senha = "1234"
let u, s = ""
let estalogado = false

while (!estalogado) {
  u = prompt("Digite o usuário: ")
  s = prompt("Digite a senha: ")
  if(u == usuario && s == senha){
    window.alert("Seja bem-vindo" + usuario)
    estaLogado = true
  } else {
    window.alert("Usuário ou senha inválidos. Tente novamente.")
  }     
}

