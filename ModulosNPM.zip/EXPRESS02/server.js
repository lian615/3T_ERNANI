//CRIAR NOSSO SERVIDOR
const express = require("express");
const path = require("path");
const app = express();

//CRIAR NOTAS
app.get("/", function (req,res){
  //NOSSO CÓDIGO VEM AQUI
});

//USAR O SERVIDOR NUMA DADA PORTA
app.listen(66666, function)

//USAR O SERVIDOR NUMA DADA PORTA
